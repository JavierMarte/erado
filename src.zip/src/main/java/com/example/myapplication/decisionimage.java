package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class decisionimage extends AppCompatActivity implements IOCRCallBack{


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    private String mAPiKey = "helloworld"; //TODO Add your own Registered API key
    private boolean isOverlayRequired;
    private String mImageUrl;
    private String mLanguage;
    private TextView mTxtResult;
    private IOCRCallBack mIOCRCallBack;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    //StorageReference mountainsRef = storageRef.child("mountains.jpg");
    StorageReference storageRef = storage.getReference("screenshot.jpg");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagescreen);
        mTxtResult = (TextView) findViewById(R.id.ocrresponse);
        mIOCRCallBack = this;
        mImageUrl = "https://firebasestorage.googleapis.com/v0/b/erado-83f05.appspot.com/o/screenshot.jpg?alt=media&token=438c965f-611b-42da-811d-45c3e6492161"; // Image url to apply OCR API
        mLanguage = "eng"; //Language
        isOverlayRequired = true;

        dispatchTakePictureIntent();
    }
    private ImageView imgCapture;
//    public void cickfortest(View view)
//    {
//
//        Intent i = new Intent(this, Test.class);
//        startActivity(i);
//
//        System.out.println("cickfortest");
//
//
//    }


    public void photo(View view)
    {
        dispatchTakePictureIntent();
    }

    static final int REQUEST_IMAGE_CAPTURE = 1;

    private void dispatchTakePictureIntent() {


        imgCapture = (ImageView) findViewById(R.id.imageView);
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
/*
            Uri photoURI = FileProvider.getUriForFile(this,
                    "com.example.android.fileprovider",
                    photoFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            */
            //startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);


//            File photoFile = null;
//            try {
//                photoFile = createImageFile();
//            } catch (IOException ex) {
//                // Error occurred while creating the File
//            //...
//            }
//            // Continue only if the File was successfully created
//            if (photoFile != null) {
//                Uri photoURI = FileProvider.getUriForFile(this,
//                        "com.example.android.fileprovider",
//                        photoFile);
//                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
//                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
//            }


            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            if (resultCode == RESULT_OK) {
                Bitmap bp = (Bitmap) data.getExtras().get("data");
                imgCapture.setImageBitmap(bp);
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            }
        }
    }


    public void unsubscribe(View view)
    {
/*


            disabled for show

        myRef.child("status").setValue("unsubscribed");


        Bitmap bitmap = ((BitmapDrawable) imgCapture.getDrawable()).getBitmap();


        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        UploadTask uploadTask = storageRef.putBytes(data);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {

                notworked();
                System.out.println("failed");
                exception.printStackTrace();


            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                worked();
                System.out.println("succesful!!");
            }
        });


*/


        worked();
    }


    public void subscribe (View view)
    {
        myRef.child("status").setValue("subscribed");


        Toast.makeText(this, "subscribed!!", Toast.LENGTH_LONG).show();

        Intent i = new Intent(this, mainscreen.class);
        // i.putExtra("message", bp);
        startActivity(i);



        //dispatchTakePictureIntent();
    }


    public void worked ()
    {

        Toast.makeText(this, "worked uploaded!!", Toast.LENGTH_LONG).show();


    }

    public void notworked ()
    {

        Toast.makeText(      this, "failed!!", Toast.LENGTH_LONG).show();


    }


    String currentPhotoPath;

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }



    public void ocr (View view)
    {



        Toast.makeText(this, "ocr!!", Toast.LENGTH_LONG).show();
        OCRAsyncTask oCRAsyncTask = new OCRAsyncTask(decisionimage.this, mAPiKey, isOverlayRequired, mImageUrl, mLanguage,mIOCRCallBack);
        oCRAsyncTask.execute();
        //Intent i = new Intent(this, mainscreen.class);
        // i.putExtra("message", bp);
       // startActivity(i);



        //dispatchTakePictureIntent();
    }

    @Override
    public void getOCRCallBackResult(String response) {


        mTxtResult.setText(response);
    }

//
//    public static Camera getCameraInstance(){
//        Camera c = null;
//        try {
//            c = Camera.open(); // attempt to get a Camera instance
//        }
//        catch (Exception e){
//            // Camera is not available (in use or does not exist)
//        }
//        return c; // returns null if camera is unavailable
//    }
}